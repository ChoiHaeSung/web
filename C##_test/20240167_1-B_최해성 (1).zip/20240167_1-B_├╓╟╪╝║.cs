﻿// See https://aka.ms/new-console-template for more information
using System.Runtime.InteropServices.Marshalling;

/*
/*
// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
// 117p
int count = 100;

Console.WriteLine("주어진 데이터값이 count = 100 일 때");
count += 5; // count = count + 5
Console.WriteLine("count += 5 " + count);

count -= 3; // count = count - 5
Console.WriteLine("count -= 3 " + count);

count *= 2; // count = count * 2
Console.WriteLine("count * =2 " + count);

count /= 10; // count = count / 10
Console.WriteLine("count /= 10 " + count);

// 118p
string fruti = "과일 -> ";

Console.WriteLine("주어진 문자열 : " +  fruti);

fruti += "사과";
Console.WriteLine("주어진 문자열 : " +  fruti);

fruti += "바나나";
Console.WriteLine("주어진 문자열 : " +  fruti);

//119
int b, c;

b = 10;
c = ++b;
Console.Write("b = 10, c = ++b 일 때 : ");
Console.WriteLine("b = " + b + ", c = " + c);

b = 10; //누적값을 배제하기 위한 변수의 값 초기화 선언
c = b++;
Console.Write("b = 10, c = b++ 일 때 : ");
Console.WriteLine("b = " + b + ", c = " + c);

b = 10; //누적값을 배제하기 위한 변수의 값 초기화 선언
c = --b;
Console.Write("b = 10, c = --b 일 때 : ");
Console.WriteLine("b = " + b + ", c = " + c);

b = 10; //누적값을 배제하기 위한 변수의 값 초기화 선언
c = b--;
Console.Write("b = 10, c = b-- 일 때 : ");
Console.WriteLine("b = " + b + ", c = " + c);


//122p
int d;

Console.Write("1. 정수 입력 :");
d = int.Parse(Console.ReadLine());

Console.WriteLine("2. 입력한 정수값 출력 : " + d);

// 123p
float e;

Console.Write("1. 실수 입력 : ");
e = float.Parse(Console.ReadLine());

Console.WriteLine("2. 입력한 실수값 출력 : " + e);




//125p
int h;
char cparse;

Console.Write("1. 문자입력 : ");
h = Console.Read();

Console.WriteLine("2. 문자의 아스키코드값이 출력 : " + h);
cparse = Convert.ToChar(h);

Console.WriteLine("3. 문자 변환 메서드를 적용하여 출력 : " + cparse);

//126p
Console.ReadLine();

string g;

Console.Write("1. 문자열 입력 : ");
g = Console.ReadLine();

Console.WriteLine("2. 입력한 문자열 출력 : " + g);


//146p
int a, choice;

Console.Write("정수 입력 : ");
a = int.Parse(Console.ReadLine());
choice = a % 2;

if (choice == 0)
{
    Console.WriteLine("짝수");
}
else
{
    Console.WriteLine("홀수");
}

//147p
int c;
char cparse;

Console.Write("문자 입력:");
c = Console.Read();
cparse = Convert.ToChar(c);

if (cparse >= 'A' && cparse <= 'Z')
{
    Console.WriteLine(" > 입력한 알파벳 : " + cparse);
    Console.WriteLine(" > 판별 결과 : 대문자 ");
}
else
{
    Console.WriteLine(" > 입력한 알파벳 : " + cparse);
    Console.WriteLine(" > 판별 결과 : 소문자 ");
}


//149p
int d;
char chocolet;

Console.WriteLine("법학과 : A 또는 a ");
Console.WriteLine("행정학과 : S 또는 s ");
Console.WriteLine("소비자학과 : D 또는 d ");
Console.WriteLine("데이터사이언스학과 : F 또는 f");
Console.WriteLine("그 이외의 알파벳 : 에러 메시지 출력 ");
Console.WriteLine();

Console.Write("알파벳 입력 : ");
d = Console.Read();
chocolet = Convert.ToChar(d);

Console.Write("선택학과 : ");

if (chocolet == 'A' || chocolet == 'a')
{
    Console.WriteLine("법학과 ");
}
else if (chocolet == 'S' || chocolet == 'S')
{
    Console.WriteLine("행정학과 ");
}


// 문제 1
int age;

Console.Write("나이를 입력하세요 : ");
age = int.Parse(Console.ReadLine());

if (age <= 99 && age >= 18)
{
    Console.WriteLine("청소년 관람불가");
}
if (age < 18 && age >= 15)
{
    Console.WriteLine("15세이상 관람가");
}
else if (age <= 14 && age >= 00)
{
    Console.WriteLine("전체 관람가");
    Console.WriteLine("시니어 할인이 적용됩니다.");
}

//문제 2

Console.WriteLine("사용자로부터 세 개의 정수를 입력받아 가장 큰 수를 출력하는 프로그램을 작성하세요.");

Console.Write("첫 번째 정수 : ");
int FirstN = int.Parse(Console.ReadLine());

Console.Write("두 번째 정수 : ");
int SecondN = int.Parse(Console.ReadLine());


Console.Write("세 번째 정수 : ");
int ThreeN = int.Parse(Console.ReadLine());

int Maxn = FirstN;

if (Maxn < SecondN)
{
    Maxn = SecondN;
}
if (Maxn < ThreeN)
{
    Maxn = ThreeN;
}
Console.WriteLine($"가장 큰 수 : {Maxn}");

 

//문제3

Console.Write("사용자로부터 구매 금액과 VIP 여부를 입력받습니다. 구매 금액에 따라 다음과 같이 할인율을 적용합니다.");

Console.WriteLine("구매 금액을 입력하세요: ");
int amount = int.Parse( Console.ReadLine());
Console.WriteLine("VIP 회원이신가요? (true/false): ");
bool isVip = Convert.ToBoolean(Console.ReadLine());

float a;
if (amount >= 100000)
{
    a = 10;
}
else if (amount >=50000 && amount < 100000)
{
    a = 5;
}
else
{
    a = 0;
}

if (isVip)
{
    a += 5;
}
Console.WriteLine(amount * (1 - a / 100));

// 문제 4 윤년 판단
Console.WriteLine("윤년인지 아닌지 판별하는 프로그램입니다.");
Console.Write("연도를 입력하세요: ");
int year = int.Parse(Console.ReadLine());

if ((year % 4 == 0 && year % 100 ! == 0) || year % 400 == 0)
{
    Console.WriteLine("윤년이 아닙니다");
}
else
{
    Console.WriteLine("윤년입니다");
}

// 문제 5 삼각형 판별 154~155P

Console.WriteLine("삼각형을 만들 수 있는지 판별하는 프로그램입니다.");

Console.Write("첫 번째 변의 길이: ");
int Fleg = int.Parse(Console.ReadLine());

Console.Write("두 번째 변의 길이: ");
int Sleg = int.Parse(Console.ReadLine());

Console.Write("세 번째 변의 길이: ");
int Tleg = int.Parse(Console.ReadLine());

if(Fleg + Sleg > Tleg && Sleg + Tleg > Fleg && Tleg + Fleg > Sleg )
{
    Console.WriteLine("삼각형을 만들 수 있습니다");
}
else
{
    Console.WriteLine("삼각형을 만들 수 없습니다");
}


// 문제 6 비만도 판정
Console.WriteLine("BMI를 계산하고 비만도를 판정하는 프로그램입니다.");
Console.Write("키(cm)를 입력하세요: ");
int Cm = int.Parse(Console.ReadLine());

Console.Write("몸무게(kg)을 입력하세요");
int Kg = int.Parse(Console.ReadLine());

int BMI = Kg / 100 * Cm * Cm;

if (BMI < 18.5)
{
    Console.WriteLine("저체중");
}
if (BMI > 18.5 && BMI <=  25)
{
    Console.WriteLine("정상");
}
if (BMI > 25 && BMI < 30)
{
    Console.WriteLine("과체중");
}
else if (BMI > 30 && BMI < 99)
{
    Console.WriteLine("비만");
}    
*/

// 문제 7 월별 날짜 수 계산
int choice;

Console.Write("월 번호를 입력하세요 (1-12): ");
choice = int.Parse(Console.ReadLine());


if (choice == 2)
{
    Console.WriteLine("28일 또는 29일");
}
else if (choice == 4 || choice == 6 || choice == 9 || choice == 11)
{
    Console.WriteLine("30일");
}
else if (choice == 1 || choice == 3 || choice == 5 || choice == 7 || choice == 8 || choice == 10 || choice == 12)
{
    Console.WriteLine("31일");
}
else
{
    Console.WriteLine("잘못된 입력입니다.");
}











